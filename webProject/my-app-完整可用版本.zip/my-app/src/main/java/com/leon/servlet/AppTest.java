package com.leon.servlet;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;


import java.io.IOException;
import java.util.Date;
import org.hibernate.Session;
import com.leon.util.HibernateUtil;
import com.leon.demo.Dbuser;


public class AppTest extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("Maven3 + Hibernate + Oracle10g");
        Session session = HibernateUtil.getSessionFactory().openSession();
 
        session.beginTransaction();
        Dbuser user = new Dbuser();
 
        user.setUserId(100);
        user.setUsername("leioolei");
        user.setCreatedBy("system");
        user.setCreatedDate(new Date());
 
        session.save(user);
        session.getTransaction().commit();
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}


}