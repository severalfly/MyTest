### 使用说明
1. 启动tomcat
2. 使用 `mvn tomcat7:deploy`

[添加subject](http://127.0.0.1:8080/exam/subjectAdd)  
[显示subject](http://127.0.0.1:8080/exam/subjectShow?subjectID=1)